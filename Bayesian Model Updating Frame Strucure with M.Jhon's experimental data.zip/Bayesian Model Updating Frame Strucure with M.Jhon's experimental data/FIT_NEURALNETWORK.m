function [net,DENORMALIZATION]=FIT_NEURALNETWORK(targets,inputs) 
% Solve an Input-Output Fitting problem with a Neural Network
DENORMALIZATION= [];
% Create a Fitting Network
hiddenLayerSize = 15;
net = fitnet(hiddenLayerSize);
net.trainParam.epochs=100;
% Set up Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;
% Train the Network
[net,~] = train(net,inputs,targets);
end