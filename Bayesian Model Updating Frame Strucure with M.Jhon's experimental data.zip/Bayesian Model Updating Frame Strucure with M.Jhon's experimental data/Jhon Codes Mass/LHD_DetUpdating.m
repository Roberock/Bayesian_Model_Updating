%close all
clear variables
clc
%% The original model: material property
E_orig = 6.9E10; % Pa
poisson_orig = 0.33; % Poisson's ratio
rho_orig = 2650; % kg/m^3 density
b_orig = 0.06; % m, width of the beam
h_orig = 0.0094; % m, thickness of the beam
% Those parameters are used (in an uncetain way) to modify the shear modulus and stiffness
% matrix
k_b_orig = 2e7; % base restrictions
a_T1_orig = 0.0047; % offset alpha of T1 joint
b_T1_orig = 0.0047; % beta T1
a_T2_orig = 0.0047; % alpha T2
b_T2_orig = 0.0047; % beta T2
a_L_orig = 0.0047; % alpha L
b_L_orig = 0.0047; % alpha L
G_b_orig=2.593984962406015e+10;
G_v_orig=2.593984962406015e+10;
Param_original=[E_orig;poisson_orig;rho_orig;b_orig;h_orig;k_b_orig;a_T1_orig;b_T1_orig;a_T2_orig;b_T2_orig;a_L_orig;b_L_orig;G_b_orig;G_v_orig]';
%% LHD design: explore model parameter space and compare it to experimental measurements
Nlhd=200;
X=lhsdesign(Nlhd,length(Param_original));
Inputs=repmat(Param_original,Nlhd,1).*0.90+repmat(Param_original,Nlhd,1).*0.2.*X;
% Experiments
Ref_exp_20_20=[17.909, 20.277, 45.674, 64.727, 190.844, 284.086]; % p1=20 cm  p2 =20 cm  %works well becasue ANN is well trained in the region between 15and25cm
Ref_exp_5_5=[20.116, 22.792, 47.520, 63.955, 183.823, 283.511]; % p1=5 cm  p2 =5 cm   %works worst becasue ANN is not well trained outside the region between 15cm 25cm (see available pool of data used to train ANN)
Ref_exp_35_35=[15.952, 17.889, 42.438, 50.659, 163.553, 257.823]; % p1=35 cm  p2 =35 cm  %works worst ..same problem
%  F_ref=[20.1160	22.7920	47.5200	63.9550	134.4220	183.8230	283.5110
% 18.7200	20.4630	46.9650	72.2400	119.1230	214.8360	296.3230
% 17.1530	18.2920	46.4180	63.4460	133.5050	196.3790	278.7000
% 19.3980	22.3940	46.3170	61.7780	136.8200	173.4940	259.7640
% 17.9090	20.2770	45.6740	64.7270	139.0710	190.8440	284.0860
% 16.7090	18.2130	45.1750	56.5270	137.8680	177.9710	264.4350
% 17.7130	21.7550	44	59.4750	131.5290	164.0480	254.4820
% 16.9110	19.8170	43.1530	60.0550	115.8680	175.7520	279.0960
% 15.9520	17.8890	42.4380	50.6590	132.2380	163.5530	257.8230
% 19.5790	21.7340	47.0020	67.5350	120.2890	196.2100	285.9450
% 16.6540	18.8470	43.9280	55.4280	125.6320	174.3520	284.8380];
% p1p2ref=[5	5; 5	20;5	35;20	5;20	20;20	35;35	5;35	20;35	35;11	11;29	29];
%% p1 p2 =  5 5
parfor i=101:Nlhd
    Natural_frequency=FrameDeterministicUpdating_20_20(Inputs(i,:));
    Natural_frequency_the6considered=Natural_frequency([1:4,6,8],:);
    NATURALFREQ_5(:,i)=Natural_frequency_the6considered(:);
    i
end
%% ANN
NormalizingFactor=mean(Inputs);
INPUTS=Inputs./repmat(NormalizingFactor,Nlhd,1);
net = feedforwardnet([18]);
net.trainParam.epochs=1000;
% Set up Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;
% Train the Network
[net,~] = train(net,INPUTS',NATURALFREQ_5);

%% Real experimental data
%% Uncomment one of the follwing if real experimental data is the one to be used
% the experiment was conduced by fixing (p1,p2)=(20cm,20cm) then (5cm,5cm) and finally (35cm,35cm)
D.Ref_exp_20=[17.909, 20.277, 45.674, 64.727, 190.844, 284.086]'; % p1=20 cm  p2 =20 cm  %
D.Ref_exp_5=[20.116, 22.792, 47.520, 63.955, 183.823, 283.511]'; % p1=5 cm  p2 =5 cm   %
D.Ref_exp_35=[15.952, 17.889, 42.438, 50.659, 163.553, 257.823]'; % p1=35 cm  p2 =35 cm  %
%% TRANSITIONAL MCMC AND BAYESIAN UPDATING
%% VARIABLE NAME  LOWER_BOUND  UPPER_BOUND
% E_orig = 6.9E10; % Pa Young's Mod
% poisson_orig = 0.33; % Poisson's ratio
% rho_orig = 2650; % kg/m^3 density
% b_orig = 0.06; % m, width of the beam
% h_orig = 0.0094; % m, thickness of the beam
% k_b_orig = 2e7; % base restrictions
% a_T1_orig = 0.0047; % offset alpha of T1 joint
% b_T1_orig = 0.0047; % beta T1
% a_T2_orig = 0.0047; % alpha T2
% b_T2_orig = 0.0047; % beta T2
% a_L_orig = 0.0047; % alpha L
% b_L_orig = 0.0047; % alpha L
% G_b_orig=2.593984962406015e+10;
% G_v_orig=2.593984962406015e+10;
variables = { ...
    'E'          6.83E10         6.97E10 	    % interval information 6.9E10
    'poisson'    0.26            0.4          % interval information 0.33
    'rho'        2550           2750          % interval information 2650
    'b'          0.0595         0.0605          % interval information 0.06
    'h'          0.00935         0.00945          % interval information 0.0094
    'k_b'        1.95e7          2.05e7 	    % interval information 2e7
    'a_T1'       0.0044         0.005        % interval information 0.0047
    'b_T1'       0.0044          0.005         % interval information 0.0047
    'a_T2'       0.0044          0.005         % interval information 0.0047
    'b_T2'       0.0044          0.005         % interval information 0.0047
    'a_L'        0.0044         0.005 	    % interval information 0.0047
    'b_L'        0.0044          0.005       % interval information 0.0047
    'G_b'        2.55+10         2.65e+10           % interval information 2.593984962406015e+10
    'G_v'        2.55+10         2.65e+10        % interval information 2.593984962406015e+10
    };
% Defining the prior PDF p(theta)
lb = cell2mat(variables(:,2))'; % lower bound
ub = cell2mat(variables(:,3))'; % upper bound
p_theta    = @(x) problemA_p_theta_pdf(x, lb, ub);
p_thetarnd = @(N) problemA_p_theta_rnd(lb, ub, N);
log_p_D_theta = @(theta) likelihood_log_p_D_theta(D, theta); % The loglikelihood of D given theta with hihg-fidelity model (time consuming)
%log_p_D_theta = @(theta) likelihood_log_p_D_theta_METAMODEL(D, theta, net, NormalizingFactor); % The loglikelihood of D given theta with metamodel

% Bayesian estimation of theta: bayesian model updating using TMCMC
Nsamples =30; % number of samples from the prior;
fprintf('Nsamples TMCMC = %d\n', Nsamples);
[samples_ftheta_D] = problemA_tmcmc(log_p_D_theta, p_theta, p_thetarnd, Nsamples);
% save([directory '/' hostname '_results_' num2str(Nexpsamples) '_samples.mat']);
Computationa_Time_Since_Measurment=toc;
display(['CPU Time for the Detection:    ' num2str(Computationa_Time_Since_Measurment) ' seconds']) % display how long the updating took
% Plot the results of the maximum likelihood and the bayesian estimations
%Histogram plot show the reduced interval in the crack variables lengths
figure(2)
for i=1:size(variables,1);
    hold on
    subplot(ceil(size(variables,1)/2),2,i);
    hist(samples_ftheta_D(:,i), ceil(sqrt(Nsamples)));
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
    AX(i,:)=axis;
end

% KDensity plots
figure(3)
for i=1:size(variables,1);
    hold on
    subplot(ceil(size(variables,1)/2),2,i);
    ksdensity(samples_ftheta_D(:,i), 'support', [lb(i) ub(i)]);
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
end
