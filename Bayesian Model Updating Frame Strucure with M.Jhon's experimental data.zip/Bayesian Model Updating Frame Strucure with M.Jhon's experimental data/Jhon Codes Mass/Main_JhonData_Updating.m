%% MODEL UPDATING FOR THE Jhon's Alluminium Frame

% Objective: Update model parameters given frequency mesurments�
% Parameters to be updated : p1 and p2 (mass 1 and mass 2 vertical positions with respect to the bottom and middle vertical beams respectivelly)
% Experimental Data: 6 natural frequencies. the 1st order inplane bending, 1st order out-of-plane bending, 1st order torsion, 2nd order in-plane bending, 2nd order outof-plane bending, and 2nd order torsion modes are obtained.

clear variables
%close all
clc

hostname = getenv('HOSTNAME');        % name of the computer
%% Load the Database of frequency responce
%The experimenal mesurments are the natural frequencies of an allminium frame with movable masses.
%
% A total of 200 synthetic mesurments were obtained from FE model. changing the mass location in the frame.
% the pair of vertical distance (p1,p2) were randomly extracted from a
% normal pdf with means (20,20) and cov C(p1,p2)=C(p2,p1)=9
TloadData=load('Data.mat');% frequency and geometirc sinthetic data
DATA=TloadData.Data;
P1=DATA.p1; % distance between orizzonatal bottom beam and mass 1
P2=DATA.p2;% distance between orizzonatal medim high beam and mass 2
P1low=DATA.loweredgegap_p1; % distance between orizzonatal bottom beam and mass 1
P2low=DATA.loweredgegap_p2;% distance between orizzonatal medim high beam and mass 2
Freq=[DATA.f(:,1:4) DATA.f(:,6:7)]; % the 6 output frequencies
%% Train a Surrogate Model to mimic Input Output FE relation
% In this case study, an Artifiial Neural Network is trained with the basic feedforward backpropagation method
% Topology : one hidden layer of 15 neurons 2 inputs and 6 outputs
[net,DENORMALIZATION]=FIT_NEURALNETWORK(Freq',[P1 P2]'); %[P1 P2 P1low P2low]
%% MESUREMENT PHASE
% we can either use one of the sinthetic mesurment randomly selected or
% real experimental data (see next section)
tic % start computational time counter
idx=randi(size(Freq,1)); % random selection of one of the simulated experiments
display('The randomly sampled experiment is:')
display(' ')
display(['Experimental p1:         ',num2str(P1(idx,:))]);
display(['Experimental p2:         ',num2str(P2(idx,:))])
Ref_exp=Freq(idx,:);
%% Real experimental data
%% Uncomment one of the follwing if real experimental data is the one to be used

% the experiment was conduced by fixing (p1,p2)=(20cm,20cm) then (5cm,5cm) and finally (35cm,35cm)
 Ref_exp=[17.909, 20.277, 45.674, 64.727, 190.844, 284.086]; % p1=20 cm  p2 =20 cm  %works well becasue ANN is well trained in the region between 15and25cm
 %Ref_exp=[20.116, 22.792, 47.520, 63.955, 183.823, 283.511]; % p1=5 cm  p2 =5 cm   %works worst becasue ANN is not well trained outside the region between 15cm 25cm (see available pool of data used to train ANN)
 %Ref_exp=[15.952, 17.889, 42.438, 50.659, 163.553, 257.823]; % p1=35 cm  p2 =35 cm  %works worst ..same problem

%% TRANSITIONAL MCMC AND BAYESIAN UPDATING
%% VARIABLE NAME  LOWER_BOUND  UPPER_BOUND

variables = { ...
    'P1'          5          35          % interval information
    'P2'          5          35          % interval information
 %     'P1_low_edge'          5          35          % interval information
 %     'P2_low_edge'          5          35          % interval information
    };
% Defining the prior PDF p(theta)
lb = cell2mat(variables(:,2))'; % lower bound
ub = cell2mat(variables(:,3))'; % upper bound
p_theta    = @(x) problemA_p_theta_pdf(x, lb, ub);
p_thetarnd = @(N) problemA_p_theta_rnd(lb, ub, N);
log_p_D_theta = @(theta) likelihood_log_p_D_theta(Ref_exp, theta,net); % The loglikelihood of D given theta
% Bayesian estimation of theta: bayesian model updating using TMCMC
Nsamples =10; % number of samples from the prior;
fprintf('Nsamples TMCMC = %d\n', Nsamples);
[samples_ftheta_D] = problemA_tmcmc(log_p_D_theta, p_theta, p_thetarnd, Nsamples);
% save([directory '/' hostname '_results_' num2str(Nexpsamples) '_samples.mat']);
Computationa_Time_Since_Measurment=toc;
display(['CPU Time for the Detection:    ' num2str(Computationa_Time_Since_Measurment) ' seconds']) % display how long the updating took
%% Plot the results of the maximum likelihood and the bayesian estimations
%Histogram plot show the reduced interval in the crack variables lengths
figure(2)
for i=1:size(variables,1);
    hold on
    subplot(1,2,i);
    hist(samples_ftheta_D(:,i), ceil(sqrt(Nsamples)));
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
    AX(i,:)=axis;
end

% KDensity plots
figure(2)
for i=1:size(variables,1);
    hold on
    subplot(1,2,i);
    ksdensity(samples_ftheta_D(:,i), 'support', [lb(i) ub(i)]);
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
end
