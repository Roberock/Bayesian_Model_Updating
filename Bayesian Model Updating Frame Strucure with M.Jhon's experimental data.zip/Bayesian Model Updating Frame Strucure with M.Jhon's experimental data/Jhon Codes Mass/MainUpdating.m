%% MODEL UPDATING FOR THE Jhon's Alluminium Frame

clear variables
close all
clc
%% Real experimental data
%% Uncomment one of the follwing if real experimental data is the one to be used
% the experiment was conduced by fixing (p1,p2)=(20cm,20cm) then (5cm,5cm) and finally (35cm,35cm)
D.Ref_exp_20=[17.909, 20.277, 45.674, 64.727, 190.844, 284.086]'; % p1=20 cm  p2 =20 cm  %works well becasue ANN is well trained in the region between 15and25cm
D.Ref_exp_5=[20.116, 22.792, 47.520, 63.955, 183.823, 283.511]'; % p1=5 cm  p2 =5 cm   %works worst becasue ANN is not well trained outside the region between 15cm 25cm (see available pool of data used to train ANN)
D.Ref_exp_35=[15.952, 17.889, 42.438, 50.659, 163.553, 257.823]'; % p1=35 cm  p2 =35 cm  %works worst ..same problem
%% TRANSITIONAL MCMC AND BAYESIAN UPDATING
%% VARIABLE NAME  LOWER_BOUND  UPPER_BOUND
% E_orig = 6.9E10; % Pa Young's Mod
% poisson_orig = 0.33; % Poisson's ratio
% rho_orig = 2650; % kg/m^3 density
% b_orig = 0.06; % m, width of the beam
% h_orig = 0.0094; % m, thickness of the beam
variables = { ...
    'E'          6.85E10      6.95E10 	    % interval information 6.9E10
    'poisson'    0.28         0.38          % interval information 0.33
    'rho'        2450         2850          % interval information 2650
    'b'          0.05         0.07          % interval information 0.06
    'h'          0.0088       0.01          % interval information 0.0094
    };
% Defining the prior PDF p(theta)
lb = cell2mat(variables(:,2))'; % lower bound
ub = cell2mat(variables(:,3))'; % upper bound
p_theta    = @(x) problemA_p_theta_pdf(x, lb, ub);
p_thetarnd = @(N) problemA_p_theta_rnd(lb, ub, N);
log_p_D_theta = @(theta) likelihood_log_p_D_theta(D, theta); % The loglikelihood of D given theta with hihg-fidelity model (time consuming)
%log_p_D_theta = @(theta) likelihood_log_p_D_theta_METAMODEL(D, theta, net); % The loglikelihood of D given theta with metamodel

% Bayesian estimation of theta: bayesian model updating using TMCMC
Nsamples =10; % number of samples from the prior;
fprintf('Nsamples TMCMC = %d\n', Nsamples);
[samples_ftheta_D] = problemA_tmcmc(log_p_D_theta, p_theta, p_thetarnd, Nsamples);
% save([directory '/' hostname '_results_' num2str(Nexpsamples) '_samples.mat']);
Computationa_Time_Since_Measurment=toc;
display(['CPU Time for the Detection:    ' num2str(Computationa_Time_Since_Measurment) ' seconds']) % display how long the updating took
%% Plot the results of the maximum likelihood and the bayesian estimations
%Histogram plot show the reduced interval in the crack variables lengths
figure(2)
for i=1:size(variables,1);
    hold on
    subplot(1,2,i);
    hist(samples_ftheta_D(:,i), ceil(sqrt(Nsamples)));
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
    AX(i,:)=axis;
end

% KDensity plots
figure(2)
for i=1:size(variables,1);
    hold on
    subplot(1,2,i);
    ksdensity(samples_ftheta_D(:,i), 'support', [lb(i) ub(i)]);
    grid on;
    title(variables{i,1},'Interpreter','none');
    xlabel('hight')
    ylabel('frequency')
end
