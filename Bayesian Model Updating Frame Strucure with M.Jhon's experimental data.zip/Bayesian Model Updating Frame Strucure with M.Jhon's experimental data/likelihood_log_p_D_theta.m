function logL = likelihood_log_p_D_theta(D, theta,net)
% Calculation of the log_likelihood for the example in problemA.m
%
% USAGE:
% logL = problemA_log_p_D_theta(D, theta)
%
% INPUTS:
% D     = experimental observations   nobs x dim_x
% theta = epistemic parameters        npar x dim_theta
%
% OUTPUTS:
% logL(i)  = loglikelihood for the set of parameters theta(i,:) and the
%            data D, i = 1, 2, ...npar.        logL = npar x 1

%--------------------------------------------------------------------------
% who                    when         observations
%--------------------------------------------------------------------------
% Diego Andres Alvarez   Jul-24-2013  First algorithm
% Rocchetta Roberto      Gen-12-2016  Modified for crack detection
%--------------------------------------------------------------------------
% Diego Andres Alvarez - daalvarez@unal.edu.co
 
%%
npar = size(theta,1);  % number of thetas to evaluate
logL = zeros(npar,1);
for i = 1:npar
   logL(i) = sum(log(p_x_theta_pdf(D, theta(i,:),net)));
   if isinf(logL(i))
      logL(i) = -1e10;
   end
end

return;

%%
function p = p_x_theta_pdf(x, theta_i,net)
 p=   (1./((x'-net(theta_i')).^2)); % likelihood (expression 1) prop to (1/SE)
 %p=  1./(2*pi).*exp(-0.5.*(x'-net(theta_i')).^2); % gaussian likelihood (expression 2) proportional to 1/(2*pi)*exp(1/2*(Xexp-Xmodel)^2)
return;
